# Offline Browser Launcher

This tool uses Puppeteer to launch a Chrome browser window that:

- Runs offline
- Uses an isolated, temporary profile
- Disables all extensions
- Prevents automatic sign-in

## Setup

```bash
npm install
```

## Run

```bash
npm start
```

This will open Chrome in offline mode with your local `public/index.html` loaded.
