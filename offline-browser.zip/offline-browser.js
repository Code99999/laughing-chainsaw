const path = require('path');
const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  const browser = await puppeteer.launch({
    headless: false,
    args: [
      '--disable-extensions',
      '--user-data-dir=/tmp/isolated-profile',
      '--incognito'
    ]
  });

  const page = await browser.newPage();

  // Set offline mode
  await page.setOfflineMode(true);

  // Load the local offline page instead
  const offlineFilePath = 'file://' + path.resolve(__dirname, 'public/index.html');
  await page.goto(offlineFilePath);
})();
